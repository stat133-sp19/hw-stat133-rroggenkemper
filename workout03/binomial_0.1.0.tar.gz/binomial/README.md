# The `binomial` Package 

Hello! This is the binomial package, lovingly created because I had to for a project. For more information about how to use this, please check the guide under "Vignettes". 
